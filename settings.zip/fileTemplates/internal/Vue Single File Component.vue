<template>
#[[$END$]]#
</template>

<script>
export default {
name: "${COMPONENT_NAME}"
}
</script>

<style lang="scss" scoped>

</style>